local mt = {};
mt.__index = mt;

local players = {};

function GM:NewPlayer( pl )
	local new = { index = pl:EntIndex(), player = pl };
	setmetatable( new, mt );

	new:SetPos( Vector( 0, 0, 0 ) );
	new:SetVelocity( Vector( 0, 0, 0 ) );
	
	players[ new.index ] = new

	return new;
end

function mt:SetPos( vec )
	self.pos = vec;
end
function mt:GetPos()
	return self.pos;
end

local floor = math.floor;
function mt:GetBlockPos( )
	local pos = self:GetPos();
	return floor( pos.x ), floor( pos.y ), floor( pos.z );
end

function mt:EyePos( )
	return self.pos + Vector( 0, 0, 1.5 );
end

function mt:EyeAngles( )
	return self.player:EyeAngles( );
end

function mt:SetVelocity( vec )
	self.vel = vec;
end

function mt:GetVelocity( )
	return self.vel;
end

function mt:ApplyForce( force )
	self.vel.x = self.vel.x + force.x;
	self.vel.y = self.vel.y + force.y;
	self.vel.z = self.vel.z + force.z;
end

function mt:Index( )
	return self.index;
end

local function offsetTrace( o, start, finish )
	local tRes = GAMEMODE:TraceLine( start + o, finish + o );
	tRes.HitPos = tRes.HitPos - o;
	return tRes;
end

local offsets = {
		Vector( -0.25, -0.25, 0 ),
		Vector( 0.25, -0.25, 0 ),
		Vector( -0.25, 0.25, 0 ),
		Vector( 0.25, 0.25, 0 ),
		Vector( -0.25, -0.25, 0.8 ),
		Vector( 0.25, -0.25, 0.8 ),
		Vector( -0.25, 0.25, 0.8 ),
		Vector( 0.25, 0.25, 0.8 ),
		Vector( -0.25, -0.25, 1.6 ),
		Vector( 0.25, -0.25, 1.6 ),
		Vector( -0.25, 0.25, 1.6 ),
		Vector( 0.25, 0.25, 1.6 )
	}

function mt:RayTrace( start, finish )
	local btRes;
	for _, o in pairs( offsets )do
		local tRes = offsetTrace( o, start, finish );
		if( not btRes or ( tRes.hit and tRes.fraction < btRes.fraction ) )then
			btRes = tRes;
		end
	end
	return btRes;
end



function mt:DoPhysicsTick( dt )
	self:ApplyForce( Vector( 0, 0, -dt*20 ) );

	if( forward )then

		local cVel = self:GetVelocity();
		self:SetVelocity( Vector( cVel.y, cVel.x, 1 ) );

		local vec = self:EyeAngles():Forward() * 10;
		vec.z = 0;
		self:SetVelocity( Vector( vec.x, vec.y, cVel.z ) );
	end
	if( jump and self:RayTrace( self:GetPos(), self:GetPos() - Vector( 0, 0, 0.2 ) ).hit)then
		local cVel = self:GetVelocity();
		self:SetVelocity( Vector( cVel.x, cVel.y, 7 ) );
	end
	
	local cPos = self:GetPos();
	local vel = self:GetVelocity( );
	vel = Vector( vel.x, vel.y, vel.z );
	cPos = Vector( cPos.x, cPos.y, cPos.z );

	for i = 1, 5 do
		if( vel:Length() <= 0 )then
			break ;
		end

		local tRes = self:RayTrace( cPos, cPos + vel*dt );

		cPos = tRes.HitPos;
		
		if( tRes.hit )then
			local step = tRes.step;
			if( step.x ~= 0 )then
				vel.x = 0;
			elseif( step.y ~= 0 )then
				vel.y = 0;
			elseif( step.z ~= 0 )then
				vel.z = 0;
			end

			cPos = cPos + tRes.step * ( -0.001 );

			local rFrac = 1 - tRes.fraction;
			
		else
			break ;
		end
	end
	vel.x, vel.y = vel.x*0.5, vel.y*0.5;

	self:SetVelocity( vel );
	self:SetPos( cPos );
end
