function GM:InitPostEntity( )
	GAMEMODE.localplayer = GAMEMODE:NewPlayer( LocalPlayer() );
	GAMEMODE.localplayer:SetPos( Vector( 0.6, 0.6, 200 ) );
	GAMEMODE.localplayer:SetVelocity( Vector( 0, 0, -1 ) );
end

GAMEMODE.localplayer = GAMEMODE:NewPlayer( LocalPlayer() );
GAMEMODE.localplayer:SetPos( Vector( 0.6, 0.6, 200 ) );
GAMEMODE.localplayer:SetVelocity( Vector( 0, 0, -1 ) );

local lastTick = CurTime( );
function GM:phys_Tick( )
	local dt = CurTime() - lastTick; -- precise timing.
	lastTick = CurTime();

	self.localplayer:DoPhysicsTick( dt );
end

concommand.Add("mc_testvel",function( ply, cmd, args )
	GAMEMODE.localplayer:SetPos( GAMEMODE.localplayer:GetPos() + Vector( 0, 0, 10 ) );
	GAMEMODE.localplayer:SetVelocity( Vector( tonumber( args[1] ), tonumber( args[2] ), tonumber( args[3] ) ) );
end);