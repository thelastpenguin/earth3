function GM:phys_PlayerSpawn( pl )
	pl.mc_ply = self:phys_NewPlayer( pl );

	
end